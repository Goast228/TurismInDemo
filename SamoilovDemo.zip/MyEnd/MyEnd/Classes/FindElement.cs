﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEnd.Classes
{
   public class FindElement
    {
        public static Tour FindTour(int ID)
        {
            using (Entities db = new Entities())
            {
                Tour tour1 = new Tour();
                foreach (Tour tour in db.Tour)
                {
                    if (tour.Id == ID)
                    {
                        tour1 = tour;
                    }
                }
                return tour1;
            }
        }
    }
}
