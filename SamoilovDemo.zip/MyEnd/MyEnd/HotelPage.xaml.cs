﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyEnd
{
    /// <summary>
    /// Логика взаимодействия для HotelPage.xaml
    /// </summary>
    public partial class HotelPage : Page
    {
        public int _CurrentPage = 1;
        public int maxPage = 0;
        public HotelPage()
        {         
            InitializeComponent();
            //using (Entities entities = new Entities())
            //{
            //    MainDataGrid.ItemsSource = entities.Hotel.ToList();
            //}            
        }
        public void RefreshHotel()
        {
            using (Entities entities = new Entities())
            {
                
                maxPage = Convert.ToInt32(Math.Ceiling(entities.Hotel.ToList().Count * 1.0 / 10));
                if (_CurrentPage > maxPage)
                {
                    _CurrentPage--;
                }
                var listHotels = entities.Hotel.ToList().Skip((_CurrentPage - 1) * 10).Take(10).ToList();

                CountPage.Text = "Из " + maxPage.ToString();
                
                currentPage.Text = _CurrentPage.ToString();
                MainDataGrid.ItemsSource = listHotels;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditPage(null));
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditPage((sender as Button).DataContext as Hotel));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
         
            var HotelsForRemoving = MainDataGrid.SelectedItems.Cast<Hotel>().ToList();
            //MessageBox.Show(HotelsForRemoving.ToString());
            if(MessageBox.Show($"Вы точно хотите удалить следующие {(HotelsForRemoving.Count())} элементов", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    using (Entities entities = new Entities())
                    {
                        foreach (Hotel hotel in HotelsForRemoving)
                        {
                            //MessageBox.Show(hotel.Name);                           
                                Hotel hotel1 = entities.Hotel.Find(hotel.Id);
                                entities.Hotel.Remove(hotel1);                                     
                        }
                        //entities.Hotel.RemoveRange(HotelsForRemoving);
                        entities.SaveChanges();
                        MessageBox.Show("Данные успешно удалены");
                        //MainDataGrid.ItemsSource = entities.Hotel.ToList();
                        RefreshHotel();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            using (Entities entities = new Entities())
            {
                entities.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                //MainDataGrid.ItemsSource = entities.Hotel.ToList();
                RefreshHotel();
            }
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            if (_CurrentPage != maxPage)
            {
                _CurrentPage++;
                RefreshHotel();
            }
            
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            if (_CurrentPage != 1)
            {
                _CurrentPage--;
                RefreshHotel();
            }
           
        }
    }
}
