﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyEnd
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private Hotel currenthotel = new Hotel();
        public AddEditPage(Hotel selectedHotel)
        {
            InitializeComponent();
            if (selectedHotel != null)
            {
                currenthotel = selectedHotel;
            }
            using (Entities entities = new Entities())
            {
                //CountriesCombo.ItemsSource = entities.Country.ToList();
                foreach (Country country in entities.Country)
                {
                    CountriesCombo.Items.Add(country.Code);
                }
            }
            DataContext = currenthotel;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(CountriesCombo.SelectedItem.ToString());
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrEmpty(currenthotel.Name))
                errors.AppendLine("Укажите название отеля");
            if (currenthotel.CountOfStars < 1 || currenthotel.CountOfStars > 5)
                errors.AppendLine("Количество звезд должно быть от 1 до 5");
            if (currenthotel.CountryCode == null)
                errors.AppendLine("Выберите страну");                       
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if (currenthotel.Id == 0)
            {
                using (Entities entities = new Entities())
                {
                    entities.Hotel.Add(currenthotel);
                    try
                    {
                        entities.SaveChanges();                 //ошибка с странами       
                        MessageBox.Show("Информация сохранена!");
                        Manager.MainFrame.GoBack();
                        //MessageBox.Show(currenthotel.Name + currenthotel.Country + currenthotel.CountOfStars);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
            else 
            {
                using (Entities entities = new Entities())
                {
                    Hotel hotel = entities.Hotel.Find(currenthotel.Id);                    
                    entities.Hotel.Remove(hotel);
                    entities.Hotel.Add(currenthotel);
                    try
                    {
                        entities.SaveChanges();                 //ошибка с странами       
                        MessageBox.Show("Информация была успешно изменена!");
                        Manager.MainFrame.GoBack();
                        //MessageBox.Show(currenthotel.Name + currenthotel.Country + currenthotel.CountOfStars);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
        }
    }
}
