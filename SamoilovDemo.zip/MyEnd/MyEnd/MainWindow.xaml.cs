﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace MyEnd
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public HotelWindow hotelWindow;
        public MainWindow()
        {
            InitializeComponent();
            Classes.ContentOfApplication.mainWindow = this;
            //Classes.ContentOfApplication.FillingTheWindow();       
            
            using (Entities database1Entities = new Entities())
            {
                Combo1.Items.Add("Все типы");
                foreach (Type type in database1Entities.Type)
                {
                    Combo1.Items.Add(type.Name);
                }
            }
            //Zapolnenie();
            Combo1.SelectedItem = 0;
        }
        public byte[] Picture;
        public void Zapolnenie()
        {
            using (Entities database1Entities = new Entities())
            {
                foreach (Tour tour in database1Entities.Tour)
                {
                    OpenFileDialog open_dialog = new OpenFileDialog();
                    open_dialog.Filter = "ImageFiles(*.BMP; *.JPG; *.GIF; *.PNG)| *.BMP; *.JPG; *.GIF; *.PNG | All files(*.*) | *.* ";
                    open_dialog.ShowDialog();
                    Picture = File.ReadAllBytes(open_dialog.FileName);
                    tour.ImagePreview = Picture;
                }
                database1Entities.SaveChanges();
            }
        }
        private void Check1_Click(object sender, RoutedEventArgs e)
        {
            //if (Check1.IsChecked == true)
            //{
            //    MainWrapPanel.Children.Clear();
            //    Classes.ContentOfApplication.FillingTheWindow(true);
            //}
            //else
            //{
            //    MainWrapPanel.Children.Clear();
            //    Classes.ContentOfApplication.FillingTheWindow();
            //}   
            Combo1_SelectionChanged(null, null);
        }

        private void Combo1_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void Combo1_SelectionChanged(object sender, RoutedEventArgs e)
        {
            //if (Classes.ContentOfApplication.mainWindow == null)
            //{
            //    Classes.ContentOfApplication.mainWindow = this;
            //}

            if (MainWrapPanel != null)
            {
                MainWrapPanel.Children.Clear();
            }
            //  string ContentOfCombo1 = Convert.ToString(Combo1.SelectedItem);
            string ContentOfCombo1 = Combo1.SelectedItem.ToString();
            int IdTypeT = 0;
            int IdTourT = 0;
            // if (ContentOfCombo1 != "Все типы")
            if (Combo1.SelectedIndex != 0)
            {
                using (Entities db = new Entities())
                {
                    foreach (Type type in db.Type)
                    {
                        if (type.Name == ContentOfCombo1)
                        {
                            IdTypeT = type.Id;
                        }
                    }
                    foreach (Relation relation in db.Relation)
                    {
                        if (relation.IdType == IdTypeT)
                        {
                            
                            IdTourT = Convert.ToInt32(relation.IdTour);
                            Tour tour = new Tour();
                            tour = Classes.FindElement.FindTour(IdTourT);
                            if (TextBoxInput.Text != "")
                            {
                                if (!tour.Name.Contains(TextBoxInput.Text))
                                {
                                    continue;
                                }
                            }
                            if (Check1.IsChecked == true && tour.IsActual == false)
                            {

                            }
                            else
                            {
                                StackPanel stackPanel = new StackPanel();
                                stackPanel.Background = new SolidColorBrush(Colors.Orange);
                                stackPanel.Orientation = Orientation.Vertical;
                                stackPanel.HorizontalAlignment = HorizontalAlignment.Center;
                                stackPanel.Height = 200;
                                stackPanel.Width = 230;
                                stackPanel.Margin = new Thickness(5, 0, 5, 5);
                                TextBlock textBlock = new TextBlock();
                                textBlock.FontSize = 15;
                                textBlock.Foreground = new SolidColorBrush(Colors.Blue);
                                textBlock.Text = tour.Name;
                                textBlock.FontFamily = new FontFamily("Comic Sans MS");
                                textBlock.Background = new SolidColorBrush(Colors.Transparent);
                                if (textBlock.Text.Length > 17)
                                {
                                    textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                                    textBlock.TextWrapping = TextWrapping.Wrap;
                                }
                                else 
                                    textBlock.HorizontalAlignment = HorizontalAlignment.Center;
                                var stream = new MemoryStream(tour.ImagePreview);////////////////////////////////
                                var image = new BitmapImage();
                                image.BeginInit();
                                image.StreamSource = stream;
                                image.EndInit();
                                Image image1 = new Image();
                                image1.Source = image;
                                image1.Height = 100;
                                image1.Width = 210;
                                Label label2 = new Label();
                                label2.FontSize = 12;
                                label2.Foreground = new SolidColorBrush(Colors.Black);
                                label2.Content = tour.Price;//Загрузка цены из БД
                                label2.HorizontalAlignment = HorizontalAlignment.Center;
                                StackPanel stackPanel2 = new StackPanel();
                                stackPanel2.Orientation = Orientation.Horizontal;
                                stackPanel2.HorizontalAlignment = HorizontalAlignment.Center;
                                Label label3 = new Label();
                                label3.FontSize = 11;
                                if (tour.IsActual)
                                {
                                    label3.Foreground = new SolidColorBrush(Colors.Green);
                                    label3.Content = "Актуален";
                                }
                                else
                                {
                                    label3.Foreground = new SolidColorBrush(Colors.Red);
                                    label3.Content = "Не актуален";
                                }
                                label3.Margin = new Thickness(0, 0, 30, 0);
                                Label label4 = new Label();
                                label4.FontSize = 11;
                                label4.Foreground = new SolidColorBrush(Colors.Black);
                                label4.Margin = new Thickness(30, 0, 0, 0);
                                label4.Content = "Билетов:" + Convert.ToString(tour.TicketCount);
                                stackPanel2.Children.Add(label3);
                                stackPanel2.Children.Add(label4);
                               stackPanel.Children.Add(textBlock);
                                stackPanel.Children.Add(image1);
                                stackPanel.Children.Add(label2);
                                stackPanel.Children.Add(stackPanel2);
                                Grid grid = new Grid();
                                grid.HorizontalAlignment = HorizontalAlignment.Left;
                                //Grid grid2 = new Grid();
                                //grid.Children.Add(border);
                                //grid2.Children.Add(textBlock);
                                //grid.Children.Add(grid2);
                                grid.Children.Add(stackPanel);
                                MainWrapPanel.Children.Add(grid);
                            }
                        }
                    }
                }
            }
            else
            {             
                using (Entities db = new Entities())
                {
                    foreach (Tour tour in db.Tour)
                    {
                        if (TextBoxInput.Text != "")
                        {
                            if (!tour.Name.Contains(TextBoxInput.Text))
                            {
                                continue;
                            }
                        }
                        if (Check1.IsChecked == true && tour.IsActual == false)
                        {

                        }
                        else
                        {
                            //Border border = new Border();
                            //border.Height = 200;
                            //border.Width = 250;
                            //border.Background = new SolidColorBrush(Colors.LightBlue);
                            StackPanel stackPanel = new StackPanel();
                            stackPanel.Background = new SolidColorBrush(Colors.Orange);
                            stackPanel.Orientation = Orientation.Vertical;
                            stackPanel.HorizontalAlignment = HorizontalAlignment.Left;
                            stackPanel.Height = 200;
                            stackPanel.Width = 230;
                            stackPanel.Margin = new Thickness(5, 0, 5, 5);
                            //Label label = new Label();
                            //label.FontSize = 12;
                            //label.Foreground = new SolidColorBrush(Colors.Yellow);
                            //label.Content = tour.Name;//Берем название тура из БД 
                            //label.HorizontalAlignment = HorizontalAlignment.Center;
                            TextBlock textBlock = new TextBlock();
                            textBlock.FontSize = 15;
                            textBlock.Foreground = new SolidColorBrush(Colors.Blue);
                            textBlock.Text = tour.Name;
                            textBlock.FontFamily = new FontFamily("Comic Sans MS");
                            textBlock.Background = new SolidColorBrush(Colors.Transparent);
                            if (textBlock.Text.Length >= 17)
                            {
                                textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                                textBlock.TextWrapping = TextWrapping.Wrap;
                            }
                            else
                                textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                            //BitmapImage bitmapImage = new BitmapImage();
                            //bitmapImage = LoadImage(tour.ImagePreview);//загружаем изображение из БД
                            //Image image = new Image();
                            //image.Source = bitmapImage;
                            //image.Width = 220;
                            //image.Height = 100;
                            var stream = new MemoryStream(tour.ImagePreview);
                            var image = new BitmapImage();
                            image.BeginInit();
                            image.StreamSource = stream;
                            image.EndInit();
                            Image image1 = new Image();
                            image1.Source = image;
                            image1.Height = 100;
                            image1.Width = 210;
                            Label label2 = new Label();
                            label2.FontSize = 12;
                            label2.Foreground = new SolidColorBrush(Colors.Black);
                            label2.Content = tour.Price;//Загрузка цены из БД
                            label2.HorizontalAlignment = HorizontalAlignment.Center;
                            StackPanel stackPanel2 = new StackPanel();
                            stackPanel2.Orientation = Orientation.Horizontal;
                            stackPanel2.HorizontalAlignment = HorizontalAlignment.Center;
                            Label label3 = new Label();
                            label3.FontSize = 11;
                            if (tour.IsActual)
                            {
                                label3.Foreground = new SolidColorBrush(Colors.Green);
                                label3.Content = "Актуален";
                            }
                            else
                            {
                                label3.Foreground = new SolidColorBrush(Colors.Red);
                                label3.Content = "Не актуален";
                            }
                            label3.Margin = new Thickness(0, 0, 30, 0);
                            Label label4 = new Label();
                            label4.FontSize = 11;
                            label4.Foreground = new SolidColorBrush(Colors.Black);
                            label4.Margin = new Thickness(30, 0, 0, 0);
                            label4.Content = "Билетов:" + Convert.ToString(tour.TicketCount);
                            stackPanel2.Children.Add(label3);
                            stackPanel2.Children.Add(label4);
                            stackPanel.Children.Add(textBlock);
                            stackPanel.Children.Add(image1);
                            stackPanel.Children.Add(label2);
                            stackPanel.Children.Add(stackPanel2);
                            Grid grid = new Grid();
                            //grid.Children.Add(border);
                            grid.Children.Add(stackPanel);
                            MainWrapPanel.Children.Add(grid);
                        }
                    }
                }
            }

        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void HotelBtn_Click(object sender, RoutedEventArgs e)
        {
            if (hotelWindow == null)
            {
                hotelWindow = new HotelWindow();
                hotelWindow.Show();
                this.Close();
            }
        }

        //public string InputText;
        //List<Hotel> HotelListInTime;
        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Combo1_SelectionChanged(null, null);
        }

        private void TextBoxInput_MouseLeave(object sender, MouseEventArgs e)
        {
            Combo1_SelectionChanged(null, null);
        }

        private void TextBoxInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            Combo1_SelectionChanged(null, null);
        }
    }
}
